# Cinematic Photo Backend

This is a simple Express backend for generating cinematic-style AI photos using the OpenAI API.

## How to Run

1. Install dependencies:
   ```
   npm install
   ```

2. Add `.env` file with:
   ```
   OPENAI_API_KEY=your-api-key-here
   ```

3. Start server:
   ```
   npm start
   ```

## Deployment

You can deploy this easily to Render.com or any Node.js platform.